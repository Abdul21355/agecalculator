// ملف: script.js

let age = 0; // لحفظ العمر المحسوب
let language = 'ar'; // اللغة الافتراضية هي العربية

// ترجمة النصوص لكل لغة
const translations = {
    ar: {
        welcomeMsg: "أهلاً بك في حاسبة العمر",
        instructions: "قم بإدخال تاريخ ميلادك لحساب عمرك.",
        labelBirthdate: "أدخل تاريخ ميلادك:",
        calculateBtn: "احسب العمر",
        resetBtn: "إعادة حساب العمر",
        showResultBtn: "عرض النتيجة",
        result: "عمرك هو: ",
        error: "الرجاء إدخال تاريخ الميلاد",
        resultError: "الرجاء حساب العمر أولاً"
    },
    en: {
        welcomeMsg: "Welcome to the Age Calculator",
        instructions: "Enter your birthdate to calculate your age.",
        labelBirthdate: "Enter your birthdate:",
        calculateBtn: "Calculate Age",
        resetBtn: "Reset Age",
        showResultBtn: "Show Result",
        result: "Your age is: ",
        error: "Please enter your birthdate",
        resultError: "Please calculate the age first"
    }
};

// تغيير اللغة بناءً على اختيار المستخدم
function setLanguage(lang) {
    language = lang;
    updateText();
}

// تحديث النصوص بناءً على اللغة المختارة
function updateText() {
    document.getElementById('welcome-msg').textContent = translations[language].welcomeMsg;
    document.getElementById('instructions').textContent = translations[language].instructions;
    document.getElementById('label-birthdate').textContent = translations[language].labelBirthdate;
    document.getElementById('calculateBtn').textContent = translations[language].calculateBtn;
    document.getElementById('resetBtn').textContent = translations[language].resetBtn;
    document.getElementById('showResultBtn').textContent = translations[language].showResultBtn;
}

// دالة حساب العمر
function calculateAge() {
    const birthdate = document.getElementById('birthdate').value;
    const resultElement = document.getElementById('result');
    
    if (!birthdate) {
        resultElement.textContent = translations[language].error;
        return;
    }

    const birthDateObj = new Date(birthdate);
    const today = new Date();
    
    age = today.getFullYear() - birthDateObj.getFullYear();
    const monthDiff = today.getMonth() - birthDateObj.getMonth();
    
    if (monthDiff < 0 || (monthDiff === 0 && today.getDate() < birthDateObj.getDate())) {
        age--;
    }

    resultElement.textContent = '';
}

// دالة إعادة تعيين الحقول
function resetForm() {
    document.getElementById('birthdate').value = '';
    document.getElementById('result').textContent = '';
}

// دالة عرض النتيجة
function showResult() {
    const resultElement = document.getElementById('result');
    if (age > 0) {
        resultElement.textContent = translations[language].result + age + (language === 'ar' ? " سنة" : " years");
    } else {
        resultElement.textContent = translations[language].resultError;
    }
}

// بدء التطبيق باللغة الافتراضية
updateText();
